# TinyGuardian

Fall detection that decides on the ESP32 and reports to a phone.

```
MPU6050 ──I2C──> ESP32 (50 Hz sampling, 13 features, 13-16-12-4 MLP)
                    │
                    ├─ core 1: sampling + inference, never blocked by wifi
                    └─ core 0: HTTPS to Supabase
                                  │
                    devices / telemetry / fall_events (PostgreSQL + RLS)
                                  │
                    Android app (Compose, polling + realtime websocket)
```

Only the decision leaves the board. Raw motion of the person stays in the room.

---

## 1. Supabase

1. Open the project dashboard, go to **SQL Editor -> New query**.
2. Paste all of `supabase/schema.sql` and run it once.
3. Check **Table Editor**: `devices` should already hold the seeded `TG-01` row.

What the file creates:

| Object | Purpose |
|---|---|
| `devices` | one row per node, heartbeat, wifi signal, caregiver phone |
| `telemetry` | one row every 2 s: class, four probabilities, 9 motion features |
| `fall_events` | one row per confirmed fall, plus the caregiver response |
| `device_overview` | the single view the app home screen reads |
| `latest_telemetry` | newest row per device |
| `touch_device` trigger | every telemetry row refreshes `last_seen`, so `online` is honest |
| `prune_telemetry(days)` | housekeeping, a node writes about 43k rows a day |

RLS is on, and the policies are demo grade: the anon key can read everything,
insert telemetry, and acknowledge alerts. Before a real deployment, move the
writes behind an edge function and give the app an authenticated role.

## 2. Firmware

Open `firmware/TinyGuardian_Cloud.ino` in the Arduino IDE, board **ESP32 Dev
Module**, and edit the four lines at the top:

```cpp
const char *WIFI_SSID = "YOUR_WIFI_NAME";
const char *WIFI_PASS = "YOUR_WIFI_PASSWORD";
const char *DEVICE_ID   = "TG-01";      // must match a row in devices
const char *DEVICE_ROOM = "Living Room";
```

Wiring:

| MPU6050 | ESP32 |
|---|---|
| VCC | 3V3 |
| GND | GND |
| SDA | GPIO21 |
| SCL | GPIO22 |

LED on GPIO2, optional active buzzer on GPIO4 (set `USE_BUZZER 0` to drop it).

Keep the board still for the two-second gyro calibration after reset. The
serial monitor at 115200 prints a status line twice a second and tells you
whether the cloud link is up.

Why two cores: an HTTPS POST takes 150 to 400 ms. If that ran inside the
sampling loop it would punch holes in the 50 Hz window and the model would see
a broken signal. Sampling and inference stay on core 1, all networking runs on
core 0, and the two share one mutex-protected snapshot plus a queue for fall
events. Falls jump the queue and go out immediately, telemetry follows every
2 s.

## 3. Android app

1. Android Studio -> **Open** -> pick the `android` folder.
2. Let it sync. Minimum SDK 26, target 35, Kotlin 2.1, Compose BOM 2025.01.00.
3. Run on a device on any network, the phone does not need to share the node's
   wifi.

The URL and anon key are already filled in at
`app/src/main/java/com/mehedi/tinyguardian/data/Models.kt`.

Four tabs:

- **Nodes**: every node with its live state, room, open alert count.
- **Live**: status hero with the confidence gauge, this second's numbers
  (impact peak, free fall dip, tilt, rotation, inference time), impact trend
  against the 2.5 g line, the four class probabilities, and node health.
- **Alerts**: fall history. Open ones carry a red edge and lead to the
  response screen: call the caregiver, log a check-in, or close as a false
  alarm. The choice is written back to `fall_events`.
- **Setup**: connection state, registered nodes, and how the detection works.

Data path: PostgREST polling every 2.5 s is the backbone, a Supabase Realtime
websocket sits on top and pulls the refresh forward to the moment a row lands.
If the socket is blocked, the chip in the Live tab reads "polling" and nothing
else changes.

## 4. Demo script

1. Power the node, wait for `Ready` on serial.
2. Open the app, tap the node, stay on the Live tab.
3. Shake the board and sit it down hard. The status stays green, which is the
   point: the model rejects it.
4. Drop it on a cushion from waist height. Within a second the LED and buzzer
   fire, the hero band turns red, the Alerts tab gets a badge.
5. Open the alert, choose "Call the caregiver now", and the row closes with the
   response recorded.

## 5. Troubleshooting

| Symptom | Cause |
|---|---|
| `MPU6050 not responding` | AD0 pulled high, so the address is 0x69. Change `MPU_ADDR`. |
| `HTTP 401` on serial | Anon key truncated. It must stay one continuous string. |
| `HTTP 409` on the devices insert | `DEVICE_ID` is missing from `devices` and the upsert header was dropped. Re-run the seed insert. |
| App shows nodes but no readings | Telemetry is arriving under a different `device_id` than the one selected. |
| Chip stuck on "polling" | Realtime is off for the tables. Re-run section 6 of the schema. |
| Everything empty, red banner | Phone has no internet, or the project is paused in Supabase. |

## 6. Retraining

The weights in the sketch are the ones from your existing model. After you
collect real data, regenerate the `TG_MEAN`, `TG_STD`, `TG_W1..TG_W3` and
`TG_B1..TG_B3` arrays with `2_train_model.py` and paste them back. The feature
extractor, the app, and the schema all stay unchanged.

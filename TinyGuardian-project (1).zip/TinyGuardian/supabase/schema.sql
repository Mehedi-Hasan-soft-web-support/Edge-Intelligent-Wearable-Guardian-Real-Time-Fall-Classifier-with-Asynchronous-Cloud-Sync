-- ===========================================================================
-- TinyGuardian  |  Supabase schema
-- Project: https://zrwapsqqptlodfgnjzjs.supabase.co
-- Run this whole file once in Supabase Studio -> SQL Editor -> New query.
-- Safe to re-run: everything is guarded with "if not exists" or "drop first".
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- 1. TABLES
-- ---------------------------------------------------------------------------

create table if not exists public.devices (
  id          text primary key,                 -- "TG-01", set in firmware
  name        text not null default 'Guardian Node',
  room        text,
  firmware    text,
  ip          text,
  rssi        int,
  uptime_s    bigint,
  caregiver   text default 'Caregiver',
  phone       text default '+8801700000000',
  last_seen   timestamptz default now(),
  created_at  timestamptz default now()
);

create table if not exists public.telemetry (
  id          bigint generated always as identity primary key,
  device_id   text not null references public.devices(id) on delete cascade,
  status      text not null check (status in ('IDLE','NORMAL','FALL','ABNORMAL')),
  confidence  real not null default 0,

  p_idle      real default 0,
  p_normal    real default 0,
  p_fall      real default 0,
  p_abnormal  real default 0,

  acc_mean    real,        -- mean |a| over the 1 s window, g
  acc_std     real,
  acc_min     real,        -- free fall dip, g
  acc_peak    real,        -- impact peak, g
  gyro_mean   real,        -- dps
  gyro_peak   real,        -- dps
  jerk        real,
  tilt        real,        -- orientation change, degrees
  stillness   real,

  infer_us    int,         -- on-device inference time
  rssi        int,
  uptime_s    bigint,
  created_at  timestamptz default now()
);

create table if not exists public.fall_events (
  id            bigint generated always as identity primary key,
  device_id     text not null references public.devices(id) on delete cascade,
  confidence    real not null,
  impact_g      real,
  freefall_g    real,
  rotation_dps  real,
  tilt_deg      real,
  event_index   bigint,

  -- filled in from the app
  response      text check (response in ('call','false_alarm','check_later')),
  note          text,
  acknowledged  boolean not null default false,
  acknowledged_at timestamptz,
  created_at    timestamptz default now()
);

create index if not exists telemetry_device_time_idx
  on public.telemetry (device_id, created_at desc);

create index if not exists fall_events_time_idx
  on public.fall_events (created_at desc);

create index if not exists fall_events_open_idx
  on public.fall_events (device_id) where acknowledged = false;

-- ---------------------------------------------------------------------------
-- 2. TRIGGERS
--    Every telemetry row refreshes the device heartbeat, so the app never has
--    to guess whether a node is alive.
-- ---------------------------------------------------------------------------

create or replace function public.touch_device()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.devices
     set last_seen = now(),
         rssi      = coalesce(new.rssi, rssi),
         uptime_s  = coalesce(new.uptime_s, uptime_s)
   where id = new.device_id;
  return new;
end;
$$;

drop trigger if exists telemetry_touch_device on public.telemetry;
create trigger telemetry_touch_device
  after insert on public.telemetry
  for each row execute function public.touch_device();

-- keep last_seen fresh on the device upsert itself
create or replace function public.stamp_last_seen()
returns trigger
language plpgsql
as $$
begin
  new.last_seen := now();
  return new;
end;
$$;

drop trigger if exists devices_stamp_last_seen on public.devices;
create trigger devices_stamp_last_seen
  before insert or update on public.devices
  for each row execute function public.stamp_last_seen();

-- ---------------------------------------------------------------------------
-- 3. VIEWS
--    device_overview is the single query the app home screen needs.
-- ---------------------------------------------------------------------------

create or replace view public.latest_telemetry
with (security_invoker = on) as
select distinct on (device_id) *
  from public.telemetry
 order by device_id, created_at desc;

create or replace view public.device_overview
with (security_invoker = on) as
select
  d.id,
  d.name,
  d.room,
  d.firmware,
  d.caregiver,
  d.phone,
  d.rssi,
  d.uptime_s,
  d.last_seen,
  (d.last_seen > now() - interval '30 seconds') as online,
  t.status,
  t.confidence,
  t.acc_peak,
  t.acc_min,
  t.tilt,
  t.gyro_peak,
  t.infer_us,
  t.created_at as updated_at,
  coalesce(a.open_alerts, 0) as open_alerts
from public.devices d
left join public.latest_telemetry t on t.device_id = d.id
left join (
  select device_id, count(*)::int as open_alerts
    from public.fall_events
   where acknowledged = false
   group by device_id
) a on a.device_id = d.id
order by d.name;

-- ---------------------------------------------------------------------------
-- 4. HOUSEKEEPING
--    A 50 Hz node writes ~43k rows a day. Trim anything older than 3 days.
--    Run manually, or schedule it with pg_cron (see the commented block).
-- ---------------------------------------------------------------------------

create or replace function public.prune_telemetry(keep_days int default 3)
returns bigint
language plpgsql
as $$
declare removed bigint;
begin
  delete from public.telemetry
   where created_at < now() - (keep_days || ' days')::interval;
  get diagnostics removed = row_count;
  return removed;
end;
$$;

-- Optional, needs the pg_cron extension enabled under Database -> Extensions:
-- select cron.schedule('tinyguardian-prune', '0 3 * * *',
--                      $$select public.prune_telemetry(3)$$);

-- ---------------------------------------------------------------------------
-- 5. ROW LEVEL SECURITY
--    Demo grade: the anon key may read everything, the node may insert, and
--    the app may acknowledge alerts. Tighten this before any real deployment
--    by moving writes behind an edge function or an authenticated role.
-- ---------------------------------------------------------------------------

alter table public.devices     enable row level security;
alter table public.telemetry   enable row level security;
alter table public.fall_events enable row level security;

drop policy if exists devices_read     on public.devices;
drop policy if exists devices_write    on public.devices;
drop policy if exists devices_update   on public.devices;
drop policy if exists telemetry_read   on public.telemetry;
drop policy if exists telemetry_write  on public.telemetry;
drop policy if exists falls_read       on public.fall_events;
drop policy if exists falls_write      on public.fall_events;
drop policy if exists falls_update     on public.fall_events;

create policy devices_read   on public.devices     for select to anon, authenticated using (true);
create policy devices_write  on public.devices     for insert to anon, authenticated with check (true);
create policy devices_update on public.devices     for update to anon, authenticated using (true) with check (true);

create policy telemetry_read  on public.telemetry  for select to anon, authenticated using (true);
create policy telemetry_write on public.telemetry  for insert to anon, authenticated with check (true);

create policy falls_read   on public.fall_events   for select to anon, authenticated using (true);
create policy falls_write  on public.fall_events   for insert to anon, authenticated with check (true);
create policy falls_update on public.fall_events   for update to anon, authenticated using (true) with check (true);

-- views inherit the policies of their base tables, but still need grants
grant select on public.device_overview   to anon, authenticated;
grant select on public.latest_telemetry  to anon, authenticated;

-- ---------------------------------------------------------------------------
-- 6. REALTIME
--    Lets the app receive new rows over a websocket instead of polling.
-- ---------------------------------------------------------------------------

do $$
begin
  alter publication supabase_realtime add table public.telemetry;
exception when duplicate_object then null;
end $$;

do $$
begin
  alter publication supabase_realtime add table public.fall_events;
exception when duplicate_object then null;
end $$;

do $$
begin
  alter publication supabase_realtime add table public.devices;
exception when duplicate_object then null;
end $$;

-- ---------------------------------------------------------------------------
-- 7. SEED
--    Registers the node so the app has something to show before first boot.
-- ---------------------------------------------------------------------------

insert into public.devices (id, name, room, firmware, caregiver, phone)
values ('TG-01', 'Guardian Node 1', 'Living Room', '1.2.0', 'Mehedi', '+8801700000000')
on conflict (id) do nothing;

-- ---------------------------------------------------------------------------
-- 8. QUICK CHECKS
-- ---------------------------------------------------------------------------
-- select * from public.device_overview;
-- select status, confidence, acc_peak, created_at
--   from public.telemetry order by created_at desc limit 20;
-- select * from public.fall_events where acknowledged = false;

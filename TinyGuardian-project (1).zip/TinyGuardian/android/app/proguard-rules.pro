# kotlinx.serialization keeps its generated serializers on the model classes
-keepclassmembers class com.mehedi.tinyguardian.data.** {
    *** Companion;
}
-keepclasseswithmembers class com.mehedi.tinyguardian.data.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-dontwarn okhttp3.**
-dontwarn okio.**

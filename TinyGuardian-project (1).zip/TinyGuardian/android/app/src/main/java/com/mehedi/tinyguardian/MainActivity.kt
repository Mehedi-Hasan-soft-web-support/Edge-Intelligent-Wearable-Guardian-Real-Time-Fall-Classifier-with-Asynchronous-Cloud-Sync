package com.mehedi.tinyguardian

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.mehedi.tinyguardian.ui.GuardianApp
import com.mehedi.tinyguardian.ui.theme.LeafMist
import com.mehedi.tinyguardian.ui.theme.TinyGuardianTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TinyGuardianTheme {
                Surface(color = LeafMist, modifier = Modifier.fillMaxSize()) {
                    GuardianApp()
                }
            }
        }
    }
}

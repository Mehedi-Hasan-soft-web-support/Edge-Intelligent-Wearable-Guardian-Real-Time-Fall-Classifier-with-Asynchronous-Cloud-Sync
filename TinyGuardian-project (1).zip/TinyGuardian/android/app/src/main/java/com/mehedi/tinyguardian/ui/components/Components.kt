package com.mehedi.tinyguardian.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mehedi.tinyguardian.data.DeviceOverview
import com.mehedi.tinyguardian.data.DeviceState
import com.mehedi.tinyguardian.ui.theme.Alert
import com.mehedi.tinyguardian.ui.theme.AlertSoft
import com.mehedi.tinyguardian.ui.theme.CardWhite
import com.mehedi.tinyguardian.ui.theme.Caution
import com.mehedi.tinyguardian.ui.theme.CautionSoft
import com.mehedi.tinyguardian.ui.theme.Hairline
import com.mehedi.tinyguardian.ui.theme.Ink
import com.mehedi.tinyguardian.ui.theme.InkMuted
import com.mehedi.tinyguardian.ui.theme.Leaf
import com.mehedi.tinyguardian.ui.theme.LeafBright
import com.mehedi.tinyguardian.ui.theme.LeafDeep
import com.mehedi.tinyguardian.ui.theme.LeafSoft
import com.mehedi.tinyguardian.ui.theme.Slate
import com.mehedi.tinyguardian.ui.theme.SlateSoft
import java.time.Duration
import java.time.Instant
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import kotlin.math.abs

// ---------------------------------------------------------------------------
// status vocabulary
// ---------------------------------------------------------------------------

fun accentFor(state: DeviceState): Color = when (state) {
    DeviceState.SAFE -> Leaf
    DeviceState.WATCH -> Caution
    DeviceState.ALERT -> Alert
    DeviceState.OFFLINE -> Slate
}

fun softFor(state: DeviceState): Color = when (state) {
    DeviceState.SAFE -> LeafSoft
    DeviceState.WATCH -> CautionSoft
    DeviceState.ALERT -> AlertSoft
    DeviceState.OFFLINE -> SlateSoft
}

fun headlineFor(device: DeviceOverview): String = when (device.state) {
    DeviceState.ALERT -> "Fall detected"
    DeviceState.WATCH -> "Unusual movement"
    DeviceState.OFFLINE -> "Node offline"
    DeviceState.SAFE -> when (device.status) {
        "IDLE" -> "Resting, all clear"
        else -> "Moving normally"
    }
}

fun statusWord(status: String?): String = when (status) {
    "FALL" -> "Fall"
    "ABNORMAL" -> "Unusual"
    "IDLE" -> "Resting"
    "NORMAL" -> "Normal"
    else -> "No data"
}

// ---------------------------------------------------------------------------
// time
// ---------------------------------------------------------------------------

fun parseStamp(iso: String?): Instant? {
    if (iso.isNullOrBlank()) return null
    return runCatching { OffsetDateTime.parse(iso).toInstant() }
        .recoverCatching { LocalDateTime.parse(iso).toInstant(ZoneOffset.UTC) }
        .getOrNull()
}

fun timeAgo(iso: String?): String {
    val stamp = parseStamp(iso) ?: return "no data yet"
    val seconds = abs(Duration.between(stamp, Instant.now()).seconds)
    return when {
        seconds < 4 -> "just now"
        seconds < 60 -> "${seconds}s ago"
        seconds < 3600 -> "${seconds / 60} min ago"
        seconds < 86_400 -> "${seconds / 3600} h ago"
        else -> "${seconds / 86_400} d ago"
    }
}

private val clock = DateTimeFormatter.ofPattern("h:mm a").withZone(ZoneId.systemDefault())
private val dayClock = DateTimeFormatter.ofPattern("d MMM, h:mm a").withZone(ZoneId.systemDefault())

fun clockTime(iso: String?): String = parseStamp(iso)?.let { clock.format(it) } ?: "--:--"
fun fullTime(iso: String?): String = parseStamp(iso)?.let { dayClock.format(it) } ?: "unknown time"

// ---------------------------------------------------------------------------
// small pieces
// ---------------------------------------------------------------------------

/** Breathing dot. Only shown when data really is arriving. */
@Composable
fun LiveDot(color: Color = LeafBright, size: Int = 8) {
    val pulse = rememberInfiniteTransition(label = "live")
    val scale by pulse.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dot"
    )
    Canvas(Modifier.size(size.dp * 2)) {
        val r = this.size.minDimension / 2f
        drawCircle(color.copy(alpha = 0.20f * scale), radius = r * scale)
        drawCircle(color, radius = r * 0.45f)
    }
}

@Composable
fun StatusChip(
    text: String,
    accent: Color,
    soft: Color,
    live: Boolean = false,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .background(soft, RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (live) {
            LiveDot(accent, size = 5)
            Spacer(Modifier.width(4.dp))
        }
        Text(
            text = text,
            color = accent,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun SectionTitle(text: String, trailing: String? = null, onTrailing: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, style = MaterialTheme.typography.titleMedium, color = Ink)
        if (trailing != null) {
            Text(
                text = trailing,
                style = MaterialTheme.typography.labelMedium,
                color = Leaf,
                modifier = Modifier.clickable(enabled = onTrailing != null) { onTrailing?.invoke() }
            )
        }
    }
}

@Composable
fun SearchPill(value: String, onValueChange: (String) -> Unit, placeholder: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(CardWhite, RoundedCornerShape(12.dp))
            .border(1.dp, Hairline, RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) {
                Text(placeholder, color = InkMuted, style = MaterialTheme.typography.bodyLarge)
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                textStyle = LocalTextStyle.current.merge(
                    MaterialTheme.typography.bodyLarge
                ).copy(color = Ink),
                cursorBrush = SolidColor(Leaf),
                modifier = Modifier.fillMaxWidth()
            )
        }
        Icon(Icons.Filled.Search, contentDescription = null, tint = InkMuted, modifier = Modifier.size(18.dp))
    }
}

/** Shield with a leaf inside, tinted by device state. Drawn, not an asset. */
@Composable
fun DeviceGlyph(state: DeviceState, size: Int = 42) {
    val accent = accentFor(state)
    Canvas(Modifier.size(size.dp)) {
        val w = this.size.width
        val h = this.size.height
        drawCircle(softFor(state))

        val shield = Path().apply {
            moveTo(w * 0.5f, h * 0.20f)
            lineTo(w * 0.76f, h * 0.31f)
            cubicTo(w * 0.76f, h * 0.62f, w * 0.66f, h * 0.74f, w * 0.5f, h * 0.82f)
            cubicTo(w * 0.34f, h * 0.74f, w * 0.24f, h * 0.62f, w * 0.24f, h * 0.31f)
            close()
        }
        drawPath(shield, accent, style = Stroke(width = w * 0.055f, join = StrokeJoin.Round))

        val leaf = Path().apply {
            moveTo(w * 0.38f, h * 0.58f)
            cubicTo(w * 0.40f, h * 0.40f, w * 0.52f, h * 0.34f, w * 0.63f, h * 0.35f)
            cubicTo(w * 0.64f, h * 0.50f, w * 0.55f, h * 0.60f, w * 0.38f, h * 0.58f)
            close()
        }
        drawPath(leaf, accent.copy(alpha = 0.85f))
        drawLine(
            color = accent,
            start = Offset(w * 0.37f, h * 0.62f),
            end = Offset(w * 0.58f, h * 0.42f),
            strokeWidth = w * 0.04f,
            cap = StrokeCap.Round
        )
    }
}

// ---------------------------------------------------------------------------
// list rows
// ---------------------------------------------------------------------------

@Composable
fun DeviceRow(device: DeviceOverview, onClick: () -> Unit) {
    val accent = accentFor(device.state)
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = CardWhite,
        border = BorderStroke(1.dp, Hairline),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            DeviceGlyph(device.state)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    device.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = Ink,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    text = headlineFor(device),
                    style = MaterialTheme.typography.bodyMedium,
                    color = accent,
                    fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    StatusChip(
                        text = device.room ?: device.id,
                        accent = InkMuted,
                        soft = SlateSoft
                    )
                    if (device.online) {
                        StatusChip(
                            text = timeAgo(device.updatedAt ?: device.lastSeen),
                            accent = LeafDeep,
                            soft = LeafSoft,
                            live = true
                        )
                    }
                    if (device.openAlerts > 0) {
                        StatusChip(
                            text = "${device.openAlerts} open",
                            accent = Alert,
                            soft = AlertSoft
                        )
                    }
                }
            }
            Icon(
                Icons.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = Slate
            )
        }
    }
}

// ---------------------------------------------------------------------------
// numbers
// ---------------------------------------------------------------------------

@Composable
fun MetricTile(
    value: String,
    unit: String,
    label: String,
    caption: String? = null,
    accent: Color = Ink,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = CardWhite,
        border = BorderStroke(1.dp, Hairline),
        modifier = modifier.width(132.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    value,
                    style = MaterialTheme.typography.headlineSmall,
                    color = accent
                )
                if (unit.isNotEmpty()) {
                    Spacer(Modifier.width(3.dp))
                    Text(
                        unit,
                        style = MaterialTheme.typography.labelMedium,
                        color = InkMuted,
                        modifier = Modifier.padding(bottom = 3.dp)
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(label, style = MaterialTheme.typography.bodyMedium, color = Ink)
            if (caption != null) {
                Spacer(Modifier.height(2.dp))
                Text(caption, style = MaterialTheme.typography.labelSmall, color = InkMuted)
            }
        }
    }
}

/** Confidence gauge: an arc, the number, and the class the model picked. */
@Composable
fun ConfidenceGauge(
    progress: Float,
    accent: Color,
    label: String,
    caption: String,
    size: Int = 116
) {
    Box(Modifier.size(size.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = this.size.minDimension * 0.085f
            val inset = stroke / 2f
            drawArc(
                color = accent.copy(alpha = 0.14f),
                startAngle = 132f,
                sweepAngle = 276f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = androidx.compose.ui.geometry.Size(
                    this.size.width - stroke,
                    this.size.height - stroke
                ),
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
            drawArc(
                color = accent,
                startAngle = 132f,
                sweepAngle = 276f * progress.coerceIn(0f, 1f),
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = androidx.compose.ui.geometry.Size(
                    this.size.width - stroke,
                    this.size.height - stroke
                ),
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                label,
                style = MaterialTheme.typography.titleLarge,
                color = accent
            )
            Text(
                caption,
                style = MaterialTheme.typography.labelSmall,
                color = InkMuted,
                fontSize = 11.sp
            )
        }
    }
}

/** Acceleration peaks over the recent window. */
@Composable
fun Sparkline(
    values: List<Float>,
    accent: Color,
    modifier: Modifier = Modifier,
    guide: Float? = null
) {
    Canvas(modifier) {
        if (values.size < 2) return@Canvas
        val maxV = maxOf(values.maxOrNull() ?: 0f, guide ?: 0f) * 1.15f
        val minV = 0f
        val span = (maxV - minV).takeIf { it > 0.01f } ?: 1f
        val stepX = size.width / (values.size - 1).toFloat()

        fun yOf(v: Float) = size.height - ((v - minV) / span) * size.height

        val line = Path()
        val fill = Path()
        values.forEachIndexed { i, v ->
            val x = stepX * i
            val y = yOf(v)
            if (i == 0) {
                line.moveTo(x, y)
                fill.moveTo(x, size.height)
                fill.lineTo(x, y)
            } else {
                line.lineTo(x, y)
                fill.lineTo(x, y)
            }
        }
        fill.lineTo(size.width, size.height)
        fill.close()

        drawPath(
            fill,
            Brush.verticalGradient(listOf(accent.copy(alpha = 0.26f), accent.copy(alpha = 0.02f)))
        )
        drawPath(
            line,
            accent,
            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        if (guide != null) {
            val y = yOf(guide)
            var x = 0f
            while (x < size.width) {
                drawLine(
                    color = Alert.copy(alpha = 0.45f),
                    start = Offset(x, y),
                    end = Offset(x + 6.dp.toPx(), y),
                    strokeWidth = 1.dp.toPx()
                )
                x += 12.dp.toPx()
            }
        }

        val lastX = stepX * (values.size - 1)
        val lastY = yOf(values.last())
        drawCircle(CardWhite, radius = 5.dp.toPx(), center = Offset(lastX, lastY))
        drawCircle(accent, radius = 3.dp.toPx(), center = Offset(lastX, lastY))
    }
}

/** Four class probabilities as one stacked bar. */
@Composable
fun ProbabilityBar(idle: Float, normal: Float, fall: Float, abnormal: Float) {
    val parts = listOf(
        Slate.copy(alpha = 0.55f) to idle,
        Leaf to normal,
        Alert to fall,
        Caution to abnormal
    )
    Canvas(Modifier.fillMaxWidth().height(10.dp)) {
        val total = parts.sumOf { it.second.toDouble() }.toFloat().takeIf { it > 0f } ?: 1f
        var x = 0f
        val radius = size.height / 2f
        parts.forEach { (color, share) ->
            val w = size.width * (share / total)
            if (w > 0.5f) {
                drawRoundRect(
                    color = color,
                    topLeft = Offset(x, 0f),
                    size = androidx.compose.ui.geometry.Size(w, size.height),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius)
                )
            }
            x += w
        }
    }
}

package com.mehedi.tinyguardian.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** Everything the app needs to reach the project. Anon key only, no secrets. */
object SupabaseConfig {
    const val PROJECT_URL = "https://zrwapsqqptlodfgnjzjs.supabase.co"
    const val ANON_KEY =
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9." +
            "eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inpyd2Fwc3FxcHRsb2RmZ25qempzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODg0MjAwNzAsImV4cCI6MjEwMzk5NjA3MH0." +
            "yNnhD6bSSWplH7IxOha2haafQYwTfCbXnZLsfOb2fCc"

    const val REST_URL = "$PROJECT_URL/rest/v1"
    const val REALTIME_URL =
        "wss://zrwapsqqptlodfgnjzjs.supabase.co/realtime/v1/websocket?apikey=$ANON_KEY&vsn=1.0.0"

    /** Node that the home screen opens first if nothing else is selected. */
    const val DEFAULT_DEVICE = "TG-01"
}

/** One row of public.device_overview. */
@Serializable
data class DeviceOverview(
    val id: String,
    val name: String = "Guardian Node",
    val room: String? = null,
    val firmware: String? = null,
    val caregiver: String? = null,
    val phone: String? = null,
    val rssi: Int? = null,
    @SerialName("uptime_s") val uptimeSeconds: Long? = null,
    @SerialName("last_seen") val lastSeen: String? = null,
    val online: Boolean = false,
    val status: String? = null,
    val confidence: Float? = null,
    @SerialName("acc_peak") val accPeak: Float? = null,
    @SerialName("acc_min") val accMin: Float? = null,
    val tilt: Float? = null,
    @SerialName("gyro_peak") val gyroPeak: Float? = null,
    @SerialName("infer_us") val inferUs: Int? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
    @SerialName("open_alerts") val openAlerts: Int = 0
) {
    val state: DeviceState
        get() = when {
            !online -> DeviceState.OFFLINE
            openAlerts > 0 -> DeviceState.ALERT
            status == "FALL" -> DeviceState.ALERT
            status == "ABNORMAL" -> DeviceState.WATCH
            else -> DeviceState.SAFE
        }
}

enum class DeviceState { SAFE, WATCH, ALERT, OFFLINE }

/** One row of public.telemetry. */
@Serializable
data class TelemetryRow(
    val id: Long = 0,
    @SerialName("device_id") val deviceId: String = "",
    val status: String = "IDLE",
    val confidence: Float = 0f,
    @SerialName("p_idle") val pIdle: Float = 0f,
    @SerialName("p_normal") val pNormal: Float = 0f,
    @SerialName("p_fall") val pFall: Float = 0f,
    @SerialName("p_abnormal") val pAbnormal: Float = 0f,
    @SerialName("acc_mean") val accMean: Float = 0f,
    @SerialName("acc_std") val accStd: Float = 0f,
    @SerialName("acc_min") val accMin: Float = 0f,
    @SerialName("acc_peak") val accPeak: Float = 0f,
    @SerialName("gyro_mean") val gyroMean: Float = 0f,
    @SerialName("gyro_peak") val gyroPeak: Float = 0f,
    val jerk: Float = 0f,
    val tilt: Float = 0f,
    val stillness: Float = 0f,
    @SerialName("infer_us") val inferUs: Int = 0,
    val rssi: Int? = null,
    @SerialName("uptime_s") val uptimeSeconds: Long? = null,
    @SerialName("created_at") val createdAt: String? = null
)

/** One row of public.fall_events. */
@Serializable
data class FallEventRow(
    val id: Long = 0,
    @SerialName("device_id") val deviceId: String = "",
    val confidence: Float = 0f,
    @SerialName("impact_g") val impactG: Float = 0f,
    @SerialName("freefall_g") val freefallG: Float = 0f,
    @SerialName("rotation_dps") val rotationDps: Float = 0f,
    @SerialName("tilt_deg") val tiltDeg: Float = 0f,
    @SerialName("event_index") val eventIndex: Long? = null,
    val response: String? = null,
    val note: String? = null,
    val acknowledged: Boolean = false,
    @SerialName("acknowledged_at") val acknowledgedAt: String? = null,
    @SerialName("created_at") val createdAt: String? = null
)

/** The three replies a caregiver can send back from the alert screen. */
enum class AlertResponse(val key: String, val title: String, val subtitle: String) {
    CALL("call", "Call the caregiver now", "Priority"),
    CHECK_LATER("check_later", "Log a check-in visit", "Standard"),
    FALSE_ALARM("false_alarm", "Mark as false alarm", "No action needed")
}

/** Health of the websocket that carries new rows to the app. */
enum class LinkState { CONNECTING, LIVE, POLLING }

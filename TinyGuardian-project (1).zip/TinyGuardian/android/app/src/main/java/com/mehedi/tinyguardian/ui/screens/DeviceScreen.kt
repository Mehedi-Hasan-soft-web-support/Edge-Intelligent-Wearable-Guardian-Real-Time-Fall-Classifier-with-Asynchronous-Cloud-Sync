package com.mehedi.tinyguardian.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mehedi.tinyguardian.data.DeviceState
import com.mehedi.tinyguardian.data.LinkState
import com.mehedi.tinyguardian.ui.GuardianUiState
import com.mehedi.tinyguardian.ui.components.ConfidenceGauge
import com.mehedi.tinyguardian.ui.components.LiveDot
import com.mehedi.tinyguardian.ui.components.MetricTile
import com.mehedi.tinyguardian.ui.components.ProbabilityBar
import com.mehedi.tinyguardian.ui.components.SectionTitle
import com.mehedi.tinyguardian.ui.components.Sparkline
import com.mehedi.tinyguardian.ui.components.StatusChip
import com.mehedi.tinyguardian.ui.components.accentFor
import com.mehedi.tinyguardian.ui.components.clockTime
import com.mehedi.tinyguardian.ui.components.headlineFor
import com.mehedi.tinyguardian.ui.components.softFor
import com.mehedi.tinyguardian.ui.components.statusWord
import com.mehedi.tinyguardian.ui.components.timeAgo
import com.mehedi.tinyguardian.ui.theme.Alert
import com.mehedi.tinyguardian.ui.theme.AlertSoft
import com.mehedi.tinyguardian.ui.theme.CardWhite
import com.mehedi.tinyguardian.ui.theme.Caution
import com.mehedi.tinyguardian.ui.theme.Hairline
import com.mehedi.tinyguardian.ui.theme.Ink
import com.mehedi.tinyguardian.ui.theme.InkMuted
import com.mehedi.tinyguardian.ui.theme.Leaf
import com.mehedi.tinyguardian.ui.theme.LeafDeep
import com.mehedi.tinyguardian.ui.theme.LeafSoft
import com.mehedi.tinyguardian.ui.theme.Slate
import com.mehedi.tinyguardian.ui.theme.SlateSoft

@Composable
fun DeviceScreen(state: GuardianUiState, onOpenAlerts: () -> Unit) {
    val device = state.selected
    var showHistory by remember { mutableStateOf(false) }

    if (device == null) {
        EmptyDevice(state.loading)
        return
    }

    val accent = accentFor(device.state)
    val latest = state.latest

    LazyColumn(
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 4.dp, bottom = 28.dp)
    ) {
        item {
            Column(
                Modifier.fillMaxWidth().padding(bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    device.name,
                    style = MaterialTheme.typography.headlineSmall,
                    color = Ink,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    "${device.id} in ${device.room ?: "an unnamed room"}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMuted
                )
            }
        }

        // ---- hero ----------------------------------------------------------
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color.Transparent,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    Modifier
                        .background(
                            when (device.state) {
                                DeviceState.ALERT -> Brush.horizontalGradient(listOf(Alert, Color(0xFFA32B22)))
                                DeviceState.OFFLINE -> Brush.horizontalGradient(listOf(Slate, Color(0xFF6F7D78)))
                                DeviceState.WATCH -> Brush.horizontalGradient(listOf(Caution, Color(0xFF8F5C0C)))
                                DeviceState.SAFE -> Brush.horizontalGradient(listOf(LeafDeep, Leaf))
                            }
                        )
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (device.online) {
                                LiveDot(CardWhite, size = 5)
                                Spacer(Modifier.width(6.dp))
                            }
                            Text(
                                if (device.online) "Live from the node" else "Last known state",
                                style = MaterialTheme.typography.labelMedium,
                                color = CardWhite.copy(alpha = 0.85f)
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            headlineFor(device),
                            style = MaterialTheme.typography.titleLarge,
                            color = CardWhite
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Updated ${timeAgo(device.updatedAt ?: device.lastSeen)}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CardWhite.copy(alpha = 0.85f)
                        )
                    }
                    Box(
                        Modifier
                            .background(CardWhite.copy(alpha = 0.14f), RoundedCornerShape(60.dp))
                            .padding(6.dp)
                    ) {
                        ConfidenceGauge(
                            progress = latest?.confidence ?: 0f,
                            accent = CardWhite,
                            label = "${((latest?.confidence ?: 0f) * 100).toInt()}%",
                            caption = statusWord(latest?.status),
                            size = 100
                        )
                    }
                }
            }
        }

        if (device.openAlerts > 0) {
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = AlertSoft,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                        .clickable(onClick = onOpenAlerts)
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Warning, null, tint = Alert, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "${device.openAlerts} fall alert waiting for your response",
                            style = MaterialTheme.typography.bodyLarge,
                            color = Alert,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // ---- live / history toggle ----------------------------------------
        item {
            Row(
                Modifier.fillMaxWidth().padding(top = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Toggle("Live", !showHistory) { showHistory = false }
                Toggle("History", showHistory) { showHistory = true }
                Spacer(Modifier.weight(1f))
                StatusChip(
                    text = when (state.link) {
                        LinkState.LIVE -> "realtime"
                        LinkState.POLLING -> "polling"
                        LinkState.CONNECTING -> "connecting"
                    },
                    accent = if (state.link == LinkState.LIVE) LeafDeep else InkMuted,
                    soft = if (state.link == LinkState.LIVE) LeafSoft else SlateSoft,
                    live = state.link == LinkState.LIVE
                )
            }
        }

        if (!showHistory) {
            item { SectionTitle("This second") }

            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        MetricTile(
                            value = fmt(latest?.accPeak),
                            unit = "g",
                            label = "Impact peak",
                            caption = "over 2.5 g reads as a hit",
                            accent = if ((latest?.accPeak ?: 0f) > 2.5f) Alert else Ink
                        )
                    }
                    item {
                        MetricTile(
                            value = fmt(latest?.accMin),
                            unit = "g",
                            label = "Free fall dip",
                            caption = "near 0 g means airborne",
                            accent = if ((latest?.accMin ?: 1f) < 0.35f) Alert else Ink
                        )
                    }
                    item {
                        MetricTile(
                            value = fmt(latest?.tilt, 0),
                            unit = "deg",
                            label = "Tilt change",
                            caption = "body orientation shift"
                        )
                    }
                    item {
                        MetricTile(
                            value = fmt(latest?.gyroPeak, 0),
                            unit = "dps",
                            label = "Peak rotation",
                            caption = "how fast it spun"
                        )
                    }
                    item {
                        MetricTile(
                            value = "${latest?.inferUs ?: 0}",
                            unit = "us",
                            label = "Inference time",
                            caption = "on the ESP32 itself",
                            accent = Leaf
                        )
                    }
                }
            }

            item { SectionTitle("Impact peaks, last ${state.trend.size} readings") }

            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = CardWhite,
                    border = BorderStroke(1.dp, Hairline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Sparkline(
                            values = state.trend.map { it.accPeak },
                            accent = accent,
                            guide = 2.5f,
                            modifier = Modifier.fillMaxWidth().height(110.dp)
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                clockTime(state.trend.firstOrNull()?.createdAt),
                                style = MaterialTheme.typography.labelSmall,
                                color = InkMuted
                            )
                            Text(
                                "dashed line: fall threshold",
                                style = MaterialTheme.typography.labelSmall,
                                color = InkMuted
                            )
                            Text(
                                clockTime(state.trend.lastOrNull()?.createdAt),
                                style = MaterialTheme.typography.labelSmall,
                                color = InkMuted
                            )
                        }
                    }
                }
            }

            item { SectionTitle("What the model sees") }

            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = CardWhite,
                    border = BorderStroke(1.dp, Hairline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        ProbabilityBar(
                            idle = latest?.pIdle ?: 0f,
                            normal = latest?.pNormal ?: 0f,
                            fall = latest?.pFall ?: 0f,
                            abnormal = latest?.pAbnormal ?: 0f
                        )
                        Spacer(Modifier.height(12.dp))
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Legend("Resting", Slate, latest?.pIdle ?: 0f)
                            Legend("Normal", Leaf, latest?.pNormal ?: 0f)
                            Legend("Fall", Alert, latest?.pFall ?: 0f)
                            Legend("Unusual", Caution, latest?.pAbnormal ?: 0f)
                        }
                    }
                }
            }

            item { SectionTitle("Node health") }

            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = CardWhite,
                    border = BorderStroke(1.dp, Hairline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        HealthRow("Wifi signal", device.rssi?.let { "$it dBm" } ?: "unknown")
                        HealthRow("Uptime", uptime(device.uptimeSeconds))
                        HealthRow("Firmware", device.firmware ?: "unknown")
                        HealthRow("Caregiver", device.phone ?: "not set", last = true)
                    }
                }
            }
        } else {
            item { SectionTitle("Recent readings") }
            items(state.trend.reversed().size) { index ->
                val row = state.trend.reversed()[index]
                val rowState = when (row.status) {
                    "FALL" -> DeviceState.ALERT
                    "ABNORMAL" -> DeviceState.WATCH
                    else -> DeviceState.SAFE
                }
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = CardWhite,
                    border = BorderStroke(1.dp, Hairline),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                ) {
                    Row(
                        Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                statusWord(row.status),
                                style = MaterialTheme.typography.titleMedium,
                                color = accentFor(rowState)
                            )
                            Text(
                                "peak ${fmt(row.accPeak)} g, tilt ${fmt(row.tilt, 0)} deg",
                                style = MaterialTheme.typography.bodyMedium,
                                color = InkMuted
                            )
                        }
                        StatusChip(
                            text = clockTime(row.createdAt),
                            accent = accentFor(rowState),
                            soft = softFor(rowState)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Toggle(text: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(50),
        color = if (selected) Ink else CardWhite,
        border = BorderStroke(1.dp, if (selected) Ink else Hairline),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) CardWhite else InkMuted,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun Legend(label: String, color: Color, share: Float) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            "${(share * 100).toInt()}%",
            style = MaterialTheme.typography.titleMedium,
            color = color
        )
        Text(label, style = MaterialTheme.typography.labelSmall, color = InkMuted)
    }
}

@Composable
private fun HealthRow(label: String, value: String, last: Boolean = false) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge, color = InkMuted)
        Text(value, style = MaterialTheme.typography.bodyLarge, color = Ink, fontWeight = FontWeight.Medium)
    }
    if (!last) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(Hairline))
    }
}

@Composable
private fun EmptyDevice(loading: Boolean) {
    Column(
        Modifier.fillMaxWidth().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            if (loading) "Reaching the cloud" else "No node selected",
            style = MaterialTheme.typography.titleLarge,
            color = Ink
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "Pick a node on the first tab to watch it live.",
            style = MaterialTheme.typography.bodyLarge,
            color = InkMuted,
            textAlign = TextAlign.Center
        )
    }
}

private fun fmt(value: Float?, decimals: Int = 2): String {
    if (value == null) return "--"
    return if (decimals == 0) value.toInt().toString()
    else String.format("%.${decimals}f", value)
}

private fun uptime(seconds: Long?): String {
    if (seconds == null) return "unknown"
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    return when {
        h > 24 -> "${h / 24} d ${h % 24} h"
        h > 0 -> "$h h $m min"
        else -> "$m min"
    }
}

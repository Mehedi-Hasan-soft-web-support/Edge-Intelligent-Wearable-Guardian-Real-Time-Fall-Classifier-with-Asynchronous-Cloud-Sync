package com.mehedi.tinyguardian.ui.theme

import androidx.compose.ui.graphics.Color

// Leaf greens: deeper and less neon than a grocery app, so a red alert always
// wins the eye. Everything else in the interface stays quiet.
val LeafDeep = Color(0xFF0E5C2E)
val Leaf = Color(0xFF178A46)
val LeafBright = Color(0xFF2FB25C)
val LeafSoft = Color(0xFFE6F3EA)
val LeafMist = Color(0xFFF4F8F4)

val Ink = Color(0xFF12211A)
val InkMuted = Color(0xFF6C7F74)
val Hairline = Color(0xFFE4EDE7)
val CardWhite = Color(0xFFFFFFFF)

val Alert = Color(0xFFC2372C)
val AlertSoft = Color(0xFFFBECEA)
val Caution = Color(0xFFB47512)
val CautionSoft = Color(0xFFFBF3E4)
val Slate = Color(0xFF8A9993)
val SlateSoft = Color(0xFFF0F3F1)

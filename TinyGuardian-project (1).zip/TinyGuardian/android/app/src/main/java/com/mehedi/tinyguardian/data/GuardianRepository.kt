package com.mehedi.tinyguardian.data

import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * Single source of truth for cloud access. Reads come from device_overview,
 * telemetry and fall_events; the only write is a caregiver acknowledging an
 * alert.
 */
object GuardianRepository {

    private val json = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
        isLenient = true
        explicitNulls = false
    }

    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val rest = SupabaseRest(http)
    private val realtime = SupabaseRealtime(http)

    suspend fun devices(): List<DeviceOverview> =
        json.decodeFromString(rest.get("/device_overview?select=*"))

    suspend fun latest(deviceId: String): TelemetryRow? =
        json.decodeFromString<List<TelemetryRow>>(
            rest.get("/telemetry?device_id=eq.$deviceId&select=*&order=created_at.desc&limit=1")
        ).firstOrNull()

    /** Oldest first, so the chart reads left to right. */
    suspend fun trend(deviceId: String, limit: Int = 40): List<TelemetryRow> =
        json.decodeFromString<List<TelemetryRow>>(
            rest.get("/telemetry?device_id=eq.$deviceId&select=*&order=created_at.desc&limit=$limit")
        ).reversed()

    suspend fun alerts(limit: Int = 50): List<FallEventRow> =
        json.decodeFromString(
            rest.get("/fall_events?select=*&order=created_at.desc&limit=$limit")
        )

    suspend fun respond(eventId: Long, response: AlertResponse, note: String? = null) {
        val payload = buildString {
            append("{\"acknowledged\":true,")
            append("\"acknowledged_at\":\"${nowIso()}\",")
            append("\"response\":\"${response.key}\"")
            if (!note.isNullOrBlank()) append(",\"note\":\"${note.escapeJson()}\"")
            append("}")
        }
        rest.patch("/fall_events?id=eq.$eventId", payload)
    }

    fun liveSignals(): Flow<RealtimeSignal> =
        realtime.changes(listOf("telemetry", "fall_events"))

    private fun nowIso(): String =
        java.time.OffsetDateTime.now(java.time.ZoneOffset.UTC)
            .format(java.time.format.DateTimeFormatter.ISO_OFFSET_DATE_TIME)

    private fun String.escapeJson(): String =
        replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ")
}

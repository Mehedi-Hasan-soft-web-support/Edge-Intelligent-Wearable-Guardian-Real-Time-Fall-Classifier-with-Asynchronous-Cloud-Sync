package com.mehedi.tinyguardian.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val GuardianColors = lightColorScheme(
    primary = Leaf,
    onPrimary = CardWhite,
    primaryContainer = LeafSoft,
    onPrimaryContainer = LeafDeep,
    secondary = LeafBright,
    onSecondary = CardWhite,
    background = LeafMist,
    onBackground = Ink,
    surface = CardWhite,
    onSurface = Ink,
    surfaceVariant = LeafSoft,
    onSurfaceVariant = InkMuted,
    error = Alert,
    onError = CardWhite,
    errorContainer = AlertSoft,
    onErrorContainer = Alert,
    outline = Hairline,
    outlineVariant = Hairline
)

private val sans = FontFamily.SansSerif

private val GuardianType = Typography(
    displaySmall = TextStyle(
        fontFamily = sans, fontWeight = FontWeight.SemiBold,
        fontSize = 40.sp, lineHeight = 44.sp, letterSpacing = (-1).sp
    ),
    headlineSmall = TextStyle(
        fontFamily = sans, fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp, lineHeight = 28.sp, letterSpacing = (-0.2).sp
    ),
    titleLarge = TextStyle(
        fontFamily = sans, fontWeight = FontWeight.SemiBold,
        fontSize = 19.sp, lineHeight = 24.sp
    ),
    titleMedium = TextStyle(
        fontFamily = sans, fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp, lineHeight = 21.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = sans, fontWeight = FontWeight.Normal,
        fontSize = 15.sp, lineHeight = 21.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = sans, fontWeight = FontWeight.Normal,
        fontSize = 13.5.sp, lineHeight = 19.sp
    ),
    labelLarge = TextStyle(
        fontFamily = sans, fontWeight = FontWeight.Medium,
        fontSize = 14.sp, lineHeight = 18.sp
    ),
    labelMedium = TextStyle(
        fontFamily = sans, fontWeight = FontWeight.Medium,
        fontSize = 12.sp, lineHeight = 16.sp
    ),
    labelSmall = TextStyle(
        fontFamily = sans, fontWeight = FontWeight.Medium,
        fontSize = 11.sp, lineHeight = 14.sp
    )
)

@Composable
fun TinyGuardianTheme(content: @Composable () -> Unit) {
    // One palette on purpose: a caregiver screen should look the same at 3 am
    // as it does at noon, and the alert red needs a light ground to read on.
    MaterialTheme(
        colorScheme = GuardianColors,
        typography = GuardianType,
        content = content
    )
}

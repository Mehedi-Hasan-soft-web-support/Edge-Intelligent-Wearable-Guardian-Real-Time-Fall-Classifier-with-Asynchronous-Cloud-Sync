package com.mehedi.tinyguardian.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.io.IOException

private val JSON_MEDIA = "application/json".toMediaType()

/**
 * Thin PostgREST wrapper. Every call carries the anon key twice, which is what
 * Supabase expects: once as the apikey header, once as a bearer token.
 */
class SupabaseRest(private val client: OkHttpClient) {

    private fun Request.Builder.auth() = this
        .header("apikey", SupabaseConfig.ANON_KEY)
        .header("Authorization", "Bearer ${SupabaseConfig.ANON_KEY}")
        .header("Accept", "application/json")

    suspend fun get(path: String): String = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(SupabaseConfig.REST_URL + path)
            .auth()
            .get()
            .build()
        client.newCall(request).execute().readOrThrow(path)
    }

    suspend fun patch(path: String, body: String): String = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(SupabaseConfig.REST_URL + path)
            .auth()
            .header("Content-Type", "application/json")
            .header("Prefer", "return=representation")
            .patch(body.toRequestBody(JSON_MEDIA))
            .build()
        client.newCall(request).execute().readOrThrow(path)
    }

    private fun Response.readOrThrow(path: String): String = use { response ->
        val text = response.body?.string().orEmpty()
        if (!response.isSuccessful) {
            throw IOException("Supabase ${response.code} on $path: ${text.take(200)}")
        }
        text
    }
}

/**
 * Supabase Realtime over a raw websocket. The app joins one channel per table
 * and emits the table name whenever a row lands, which the repository turns
 * into an immediate refresh. If the socket ever drops, polling still carries
 * the screen, so a failure here degrades quality rather than breaking the app.
 */
class SupabaseRealtime(private val client: OkHttpClient) {

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    fun changes(tables: List<String>): Flow<RealtimeSignal> = callbackFlow {
        var reference = 0
        fun nextRef() = (++reference).toString()

        val listener = object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                tables.forEach { table -> webSocket.send(joinMessage(table, nextRef())) }
                trySend(RealtimeSignal.Connected)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                runCatching {
                    val root = json.parseToJsonElement(text).jsonObject
                    when (root["event"]?.jsonPrimitive?.content) {
                        "postgres_changes" -> {
                            val table = root["payload"]?.jsonObject
                                ?.get("data")?.jsonObject
                                ?.get("table")?.jsonPrimitive?.content
                            if (table != null) trySend(RealtimeSignal.Row(table))
                        }

                        "phx_error" -> trySend(RealtimeSignal.Dropped)
                    }
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                trySend(RealtimeSignal.Dropped)
                close(t)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                trySend(RealtimeSignal.Dropped)
                close()
            }
        }

        val request = Request.Builder().url(SupabaseConfig.REALTIME_URL).build()
        val socket = client.newWebSocket(request, listener)

        // Phoenix drops any channel that goes quiet for a minute.
        val heartbeat = launch {
            while (isActive) {
                delay(25_000)
                socket.send(
                    """{"topic":"phoenix","event":"heartbeat","payload":{},"ref":"${nextRef()}"}"""
                )
            }
        }

        awaitClose {
            heartbeat.cancel()
            socket.close(1000, "app closed the channel")
        }
    }

    private fun joinMessage(table: String, ref: String) = """
        {"topic":"realtime:public:$table","event":"phx_join","payload":{"config":{
        "broadcast":{"self":false},"presence":{"key":""},
        "postgres_changes":[{"event":"*","schema":"public","table":"$table"}]}},
        "ref":"$ref"}
    """.trimIndent().replace("\n", "")
}

sealed interface RealtimeSignal {
    data object Connected : RealtimeSignal
    data object Dropped : RealtimeSignal
    data class Row(val table: String) : RealtimeSignal
}

package com.mehedi.tinyguardian.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mehedi.tinyguardian.data.LinkState
import com.mehedi.tinyguardian.data.SupabaseConfig
import com.mehedi.tinyguardian.ui.GuardianUiState
import com.mehedi.tinyguardian.ui.components.SectionTitle
import com.mehedi.tinyguardian.ui.components.StatusChip
import com.mehedi.tinyguardian.ui.components.timeAgo
import com.mehedi.tinyguardian.ui.theme.CardWhite
import com.mehedi.tinyguardian.ui.theme.Hairline
import com.mehedi.tinyguardian.ui.theme.Ink
import com.mehedi.tinyguardian.ui.theme.InkMuted
import com.mehedi.tinyguardian.ui.theme.LeafDeep
import com.mehedi.tinyguardian.ui.theme.LeafSoft
import com.mehedi.tinyguardian.ui.theme.SlateSoft
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(state: GuardianUiState) {
    LazyColumn(
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 4.dp, bottom = 28.dp)
    ) {
        item {
            Text("Setup", style = MaterialTheme.typography.headlineSmall, color = Ink)
        }

        item { SectionTitle("Cloud link") }

        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = CardWhite,
                border = BorderStroke(1.dp, Hairline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    InfoRow("Project", SupabaseConfig.PROJECT_URL.removePrefix("https://"))
                    InfoRow(
                        "Transport",
                        when (state.link) {
                            LinkState.LIVE -> "websocket, rows arrive as they land"
                            LinkState.POLLING -> "polling every 2.5 s"
                            LinkState.CONNECTING -> "opening the websocket"
                        }
                    )
                    InfoRow(
                        "Last sync",
                        if (state.lastSync == 0L) "waiting"
                        else SimpleDateFormat("h:mm:ss a", Locale.getDefault()).format(Date(state.lastSync))
                    )
                    InfoRow("Tables", "devices, telemetry, fall_events", last = true)
                }
            }
        }

        item { SectionTitle("Registered nodes") }

        items(state.devices.size) { index ->
            val device = state.devices[index]
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = CardWhite,
                border = BorderStroke(1.dp, Hairline),
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
            ) {
                Row(
                    Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            device.name,
                            style = MaterialTheme.typography.titleMedium,
                            color = Ink,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            "${device.id}, firmware ${device.firmware ?: "unknown"}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = InkMuted
                        )
                    }
                    StatusChip(
                        text = if (device.online) "online" else timeAgo(device.lastSeen),
                        accent = if (device.online) LeafDeep else InkMuted,
                        soft = if (device.online) LeafSoft else SlateSoft
                    )
                }
            }
        }

        item { SectionTitle("How detection works") }

        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = LeafSoft,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        "The node keeps every decision on the board",
                        style = MaterialTheme.typography.titleMedium,
                        color = LeafDeep
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "An MPU6050 samples at 50 Hz. Each second of motion becomes 13 features, " +
                            "and a 13-16-12-4 network on the ESP32 sorts it into resting, normal, " +
                            "fall or unusual. Only the result travels to the cloud, so the raw " +
                            "motion of the person never leaves the room.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = LeafDeep.copy(alpha = 0.85f)
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                        Spec("0.80", "fall confidence gate")
                        Spec("4 s", "repeat lockout")
                        Spec("2 s", "telemetry interval")
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String, last: Boolean = false) {
    Column {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 9.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.bodyLarge, color = InkMuted)
            Text(
                value,
                style = MaterialTheme.typography.bodyMedium,
                color = Ink,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(start = 16.dp)
            )
        }
        if (!last) Box(Modifier.fillMaxWidth().height(1.dp).background(Hairline))
    }
}

@Composable
private fun Spec(value: String, label: String) {
    Column {
        Text(value, style = MaterialTheme.typography.titleMedium, color = LeafDeep)
        Text(label, style = MaterialTheme.typography.labelSmall, color = LeafDeep.copy(alpha = 0.75f))
    }
}

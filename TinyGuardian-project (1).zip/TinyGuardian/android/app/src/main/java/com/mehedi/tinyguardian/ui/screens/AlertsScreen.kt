package com.mehedi.tinyguardian.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mehedi.tinyguardian.data.FallEventRow
import com.mehedi.tinyguardian.ui.GuardianUiState
import com.mehedi.tinyguardian.ui.components.StatusChip
import com.mehedi.tinyguardian.ui.components.fullTime
import com.mehedi.tinyguardian.ui.components.timeAgo
import com.mehedi.tinyguardian.ui.theme.Alert
import com.mehedi.tinyguardian.ui.theme.AlertSoft
import com.mehedi.tinyguardian.ui.theme.CardWhite
import com.mehedi.tinyguardian.ui.theme.Hairline
import com.mehedi.tinyguardian.ui.theme.Ink
import com.mehedi.tinyguardian.ui.theme.InkMuted
import com.mehedi.tinyguardian.ui.theme.Leaf
import com.mehedi.tinyguardian.ui.theme.LeafDeep
import com.mehedi.tinyguardian.ui.theme.LeafSoft
import com.mehedi.tinyguardian.ui.theme.SlateSoft

@Composable
fun AlertsScreen(state: GuardianUiState, onOpen: (FallEventRow) -> Unit) {
    LazyColumn(
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 4.dp, bottom = 28.dp)
    ) {
        item {
            Column(Modifier.fillMaxWidth().padding(bottom = 14.dp)) {
                Text("Fall alerts", style = MaterialTheme.typography.headlineSmall, color = Ink)
                Spacer(Modifier.height(3.dp))
                Text(
                    if (state.openAlerts.isEmpty()) "Every alert has been answered."
                    else "${state.openAlerts.size} still need a response.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (state.openAlerts.isEmpty()) LeafDeep else Alert
                )
            }
        }

        if (state.alerts.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = LeafSoft,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.CheckCircle, null, tint = Leaf, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(
                                "No falls so far",
                                style = MaterialTheme.typography.titleMedium,
                                color = LeafDeep
                            )
                            Text(
                                "The node keeps watching and writes here the moment something happens.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = LeafDeep.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }
        }

        items(state.alerts.size) { index ->
            val event = state.alerts[index]
            AlertCard(event = event, onClick = { onOpen(event) })
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun AlertCard(event: FallEventRow, onClick: () -> Unit) {
    val open = !event.acknowledged
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = CardWhite,
        border = BorderStroke(1.dp, if (open) Alert.copy(alpha = 0.35f) else Hairline),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(Modifier.height(IntrinsicSize.Min)) {
            Box(
                Modifier
                    .width(4.dp)
                    .fillMaxHeight()
                    .background(if (open) Alert else Leaf)
            )
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (open) "Fall detected" else "Fall handled",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (open) Alert else Ink
                    )
                    Spacer(Modifier.weight(1f))
                    Text(
                        timeAgo(event.createdAt),
                        style = MaterialTheme.typography.labelMedium,
                        color = InkMuted
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    fullTime(event.createdAt),
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMuted
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    StatusChip(
                        text = event.deviceId,
                        accent = InkMuted,
                        soft = SlateSoft
                    )
                    StatusChip(
                        text = "${(event.confidence * 100).toInt()}% sure",
                        accent = if (open) Alert else LeafDeep,
                        soft = if (open) AlertSoft else LeafSoft
                    )
                    StatusChip(
                        text = String.format("%.1f g impact", event.impactG),
                        accent = InkMuted,
                        soft = SlateSoft
                    )
                }
                if (open) {
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Choose a response",
                            style = MaterialTheme.typography.labelLarge,
                            color = Alert,
                            fontWeight = FontWeight.SemiBold
                        )
                        Icon(
                            Icons.Filled.KeyboardArrowRight,
                            contentDescription = null,
                            tint = Alert,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                } else if (event.response != null) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Marked as ${event.response.replace('_', ' ')}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = LeafDeep
                    )
                }
            }
        }
    }
}

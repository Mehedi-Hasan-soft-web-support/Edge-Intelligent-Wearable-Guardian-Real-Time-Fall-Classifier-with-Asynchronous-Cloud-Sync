package com.mehedi.tinyguardian.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mehedi.tinyguardian.ui.GuardianUiState
import com.mehedi.tinyguardian.ui.components.DeviceRow
import com.mehedi.tinyguardian.ui.components.SearchPill
import com.mehedi.tinyguardian.ui.components.SectionTitle
import com.mehedi.tinyguardian.ui.components.timeAgo
import com.mehedi.tinyguardian.ui.theme.Alert
import com.mehedi.tinyguardian.ui.theme.AlertSoft
import com.mehedi.tinyguardian.ui.theme.CardWhite
import com.mehedi.tinyguardian.ui.theme.Hairline
import com.mehedi.tinyguardian.ui.theme.Ink
import com.mehedi.tinyguardian.ui.theme.InkMuted
import com.mehedi.tinyguardian.ui.theme.Leaf
import com.mehedi.tinyguardian.ui.theme.LeafDeep
import com.mehedi.tinyguardian.ui.theme.LeafSoft

@Composable
fun HomeScreen(
    state: GuardianUiState,
    onSearch: (String) -> Unit,
    onOpenDevice: (String) -> Unit,
    onOpenAlerts: () -> Unit,
    onRetry: () -> Unit
) {
    val caregiver = state.devices.firstNotNullOfOrNull { it.caregiver } ?: "there"
    val place = state.selected?.room ?: state.devices.firstOrNull()?.room ?: "No room set"

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            start = 18.dp, end = 18.dp, top = 8.dp, bottom = 28.dp
        )
    ) {
        item {
            Column(
                Modifier.fillMaxWidth().padding(bottom = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Hello, $caregiver",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Ink,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        place,
                        style = MaterialTheme.typography.labelLarge,
                        color = Leaf
                    )
                    Icon(
                        Icons.Filled.KeyboardArrowDown,
                        contentDescription = null,
                        tint = Leaf,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        item {
            SearchPill(
                value = state.query,
                onValueChange = onSearch,
                placeholder = "Search nodes or rooms"
            )
        }

        if (state.error != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = AlertSoft,
                    modifier = Modifier.fillMaxWidth().padding(top = 14.dp)
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Warning, null, tint = Alert, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "Cloud is out of reach",
                                style = MaterialTheme.typography.titleMedium,
                                color = Alert
                            )
                            Text(
                                "Check the phone network, then try again.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Ink
                            )
                        }
                        Icon(
                            Icons.Filled.Refresh,
                            contentDescription = "Try again",
                            tint = Alert,
                            modifier = Modifier.size(22.dp).clickable(onClick = onRetry)
                        )
                    }
                }
            }
        }

        val open = state.openAlerts
        if (open.isNotEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Alert,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 14.dp)
                        .clickable(onClick = onOpenAlerts)
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (open.size == 1) "1 fall needs a response"
                                else "${open.size} falls need a response",
                                style = MaterialTheme.typography.titleMedium,
                                color = CardWhite
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                "Latest ${timeAgo(open.first().createdAt)} on ${open.first().deviceId}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = CardWhite.copy(alpha = 0.85f)
                            )
                        }
                        Text(
                            "Open",
                            style = MaterialTheme.typography.labelLarge,
                            color = CardWhite
                        )
                    }
                }
            }
        }

        item { SectionTitle("Your nodes") }

        if (state.visibleDevices.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = CardWhite,
                    border = BorderStroke(1.dp, Hairline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Text(
                            if (state.loading) "Looking for nodes" else "No node has reported yet",
                            style = MaterialTheme.typography.titleMedium,
                            color = Ink
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Flash the firmware, set the wifi name and password, then watch this list fill in.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = InkMuted
                        )
                    }
                }
            }
        }

        items(state.visibleDevices.size) { index ->
            val device = state.visibleDevices[index]
            DeviceRow(device = device, onClick = { onOpenDevice(device.id) })
            Spacer(Modifier.height(10.dp))
        }

        item { SectionTitle("Watch summary") }

        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = LeafSoft,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    SummaryStat("${state.devices.count { it.online }}/${state.devices.size}", "nodes online")
                    SummaryStat("${state.alerts.size}", "falls recorded")
                    SummaryStat("${state.openAlerts.size}", "awaiting reply")
                }
            }
        }
    }
}

@Composable
private fun SummaryStat(value: String, label: String) {
    Column {
        Text(value, style = MaterialTheme.typography.titleLarge, color = LeafDeep)
        Spacer(Modifier.height(2.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = LeafDeep.copy(alpha = 0.75f))
    }
}

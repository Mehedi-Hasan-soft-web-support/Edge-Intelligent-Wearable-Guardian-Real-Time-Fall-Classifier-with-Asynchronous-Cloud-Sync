package com.mehedi.tinyguardian.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mehedi.tinyguardian.data.AlertResponse
import com.mehedi.tinyguardian.data.DeviceOverview
import com.mehedi.tinyguardian.data.FallEventRow
import com.mehedi.tinyguardian.ui.components.fullTime
import com.mehedi.tinyguardian.ui.theme.Alert
import com.mehedi.tinyguardian.ui.theme.AlertSoft
import com.mehedi.tinyguardian.ui.theme.CardWhite
import com.mehedi.tinyguardian.ui.theme.Hairline
import com.mehedi.tinyguardian.ui.theme.Ink
import com.mehedi.tinyguardian.ui.theme.InkMuted
import com.mehedi.tinyguardian.ui.theme.Leaf
import com.mehedi.tinyguardian.ui.theme.LeafSoft

@Composable
fun RespondScreen(
    event: FallEventRow,
    device: DeviceOverview?,
    onBack: () -> Unit,
    onSend: (AlertResponse) -> Unit
) {
    var choice by remember { mutableStateOf(AlertResponse.CALL) }
    val context = LocalContext.current
    val phone = device?.phone ?: "+8801700000000"

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = Ink,
                modifier = Modifier.size(22.dp).clickable(onClick = onBack)
            )
            Spacer(Modifier.width(12.dp))
            Text("Choose a response", style = MaterialTheme.typography.titleLarge, color = Ink)
        }

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = AlertSoft,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp)) {
                Text(
                    "Fall on ${event.deviceId}",
                    style = MaterialTheme.typography.titleMedium,
                    color = Alert
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    fullTime(event.createdAt),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Ink
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    Fact("${(event.confidence * 100).toInt()}%", "confidence")
                    Fact(String.format("%.1f g", event.impactG), "impact")
                    Fact(String.format("%.2f g", event.freefallG), "free fall")
                    Fact("${event.tiltDeg.toInt()} deg", "tilt")
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        AlertResponse.entries.forEach { option ->
            OptionCard(
                title = option.title,
                subtitle = option.subtitle,
                selected = choice == option,
                onClick = { choice = option }
            )
            Spacer(Modifier.height(10.dp))
        }

        Spacer(Modifier.height(8.dp))

        Surface(
            shape = RoundedCornerShape(14.dp),
            color = Leaf,
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    if (choice == AlertResponse.CALL) {
                        runCatching {
                            context.startActivity(
                                Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
                            )
                        }
                    }
                    onSend(choice)
                }
        ) {
            Text(
                text = when (choice) {
                    AlertResponse.CALL -> "Call and close the alert"
                    AlertResponse.CHECK_LATER -> "Log the check-in"
                    AlertResponse.FALSE_ALARM -> "Close as false alarm"
                },
                style = MaterialTheme.typography.titleMedium,
                color = CardWhite,
                modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }

        Spacer(Modifier.height(14.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .clickable {
                    runCatching {
                        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")))
                    }
                }
                .padding(vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Call, contentDescription = null, tint = Ink, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(phone, style = MaterialTheme.typography.bodyLarge, color = Ink)
                Text(
                    device?.caregiver ?: "Caregiver on file",
                    style = MaterialTheme.typography.labelSmall,
                    color = InkMuted
                )
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Fact(value: String, label: String) {
    Column {
        Text(value, style = MaterialTheme.typography.titleMedium, color = Ink)
        Text(label, style = MaterialTheme.typography.labelSmall, color = InkMuted)
    }
}

@Composable
private fun OptionCard(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (selected) LeafSoft else CardWhite,
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) Leaf else Hairline),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(
            Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Canvas(Modifier.size(20.dp)) {
                drawCircle(
                    color = if (selected) Leaf else Hairline,
                    style = Stroke(width = 2.dp.toPx())
                )
                if (selected) drawCircle(color = Leaf, radius = size.minDimension / 4f)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleMedium,
                    color = Ink,
                    fontWeight = FontWeight.Medium
                )
                Text(subtitle, style = MaterialTheme.typography.labelMedium, color = InkMuted)
            }
        }
    }
}

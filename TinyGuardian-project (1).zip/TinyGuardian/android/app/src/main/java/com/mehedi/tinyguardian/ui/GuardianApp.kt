package com.mehedi.tinyguardian.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mehedi.tinyguardian.data.FallEventRow
import com.mehedi.tinyguardian.ui.screens.AlertsScreen
import com.mehedi.tinyguardian.ui.screens.DeviceScreen
import com.mehedi.tinyguardian.ui.screens.HomeScreen
import com.mehedi.tinyguardian.ui.screens.RespondScreen
import com.mehedi.tinyguardian.ui.screens.SettingsScreen
import com.mehedi.tinyguardian.ui.theme.Alert
import com.mehedi.tinyguardian.ui.theme.CardWhite
import com.mehedi.tinyguardian.ui.theme.Hairline
import com.mehedi.tinyguardian.ui.theme.Ink
import com.mehedi.tinyguardian.ui.theme.Leaf
import com.mehedi.tinyguardian.ui.theme.LeafMist
import com.mehedi.tinyguardian.ui.theme.Slate

private enum class Tab(val label: String) {
    NODES("Nodes"), LIVE("Live"), ALERTS("Alerts"), SETUP("Setup")
}

@Composable
fun GuardianApp(viewModel: GuardianViewModel = viewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var tab by remember { mutableStateOf(Tab.NODES) }
    var respondTo by remember { mutableStateOf<FallEventRow?>(null) }

    BackHandler(enabled = respondTo != null || tab != Tab.NODES) {
        when {
            respondTo != null -> respondTo = null
            else -> tab = Tab.NODES
        }
    }

    Scaffold(
        containerColor = LeafMist,
        bottomBar = {
            if (respondTo == null) {
                GuardianBottomBar(
                    current = tab,
                    openAlerts = state.openAlerts.size,
                    onSelect = { tab = it }
                )
            }
        },
        modifier = Modifier.safeDrawingPadding()
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            val event = respondTo
            if (event != null) {
                RespondScreen(
                    event = event,
                    device = state.devices.firstOrNull { it.id == event.deviceId },
                    onBack = { respondTo = null },
                    onSend = { response ->
                        viewModel.respond(event, response)
                        respondTo = null
                    }
                )
            } else {
                when (tab) {
                    Tab.NODES -> HomeScreen(
                        state = state,
                        onSearch = viewModel::search,
                        onOpenDevice = { id ->
                            viewModel.select(id)
                            tab = Tab.LIVE
                        },
                        onOpenAlerts = { tab = Tab.ALERTS },
                        onRetry = viewModel::retry
                    )

                    Tab.LIVE -> DeviceScreen(
                        state = state,
                        onOpenAlerts = { tab = Tab.ALERTS }
                    )

                    Tab.ALERTS -> AlertsScreen(
                        state = state,
                        onOpen = { event2 -> if (!event2.acknowledged) respondTo = event2 }
                    )

                    Tab.SETUP -> SettingsScreen(state = state)
                }
            }
        }
    }
}

@Composable
private fun GuardianBottomBar(current: Tab, openAlerts: Int, onSelect: (Tab) -> Unit) {
    Column {
        Box(Modifier.fillMaxWidth().height(1.dp).background(Hairline))
        NavigationBar(
            containerColor = CardWhite,
            tonalElevation = 0.dp
        ) {
            Tab.entries.forEach { entry ->
                val selected = entry == current
                NavigationBarItem(
                    selected = selected,
                    onClick = { onSelect(entry) },
                    icon = {
                        when (entry) {
                            Tab.NODES -> Icon(Icons.Filled.Home, contentDescription = entry.label)
                            Tab.LIVE -> PulseGlyph(if (selected) Leaf else Slate)
                            Tab.ALERTS -> BadgedBox(
                                badge = {
                                    if (openAlerts > 0) {
                                        Badge(containerColor = Alert, contentColor = CardWhite) {
                                            Text("$openAlerts")
                                        }
                                    }
                                }
                            ) {
                                Icon(Icons.Filled.Notifications, contentDescription = entry.label)
                            }

                            Tab.SETUP -> Icon(Icons.Filled.Settings, contentDescription = entry.label)
                        }
                    },
                    label = { Text(entry.label) },
                    alwaysShowLabel = true,
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Leaf,
                        selectedTextColor = Ink,
                        unselectedIconColor = Slate,
                        unselectedTextColor = Slate,
                        indicatorColor = CardWhite
                    )
                )
            }
        }
    }
}

/** Heartbeat trace for the live tab, drawn rather than shipped as an asset. */
@Composable
private fun PulseGlyph(color: Color) {
    Canvas(Modifier.size(24.dp)) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(w * 0.06f, h * 0.55f)
            lineTo(w * 0.30f, h * 0.55f)
            lineTo(w * 0.40f, h * 0.24f)
            lineTo(w * 0.54f, h * 0.80f)
            lineTo(w * 0.64f, h * 0.48f)
            lineTo(w * 0.74f, h * 0.55f)
            lineTo(w * 0.94f, h * 0.55f)
        }
        drawPath(
            path,
            color,
            style = Stroke(width = w * 0.10f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

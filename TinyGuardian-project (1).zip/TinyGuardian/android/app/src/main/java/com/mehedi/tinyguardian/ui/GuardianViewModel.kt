package com.mehedi.tinyguardian.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mehedi.tinyguardian.data.AlertResponse
import com.mehedi.tinyguardian.data.DeviceOverview
import com.mehedi.tinyguardian.data.FallEventRow
import com.mehedi.tinyguardian.data.GuardianRepository
import com.mehedi.tinyguardian.data.LinkState
import com.mehedi.tinyguardian.data.RealtimeSignal
import com.mehedi.tinyguardian.data.SupabaseConfig
import com.mehedi.tinyguardian.data.TelemetryRow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class GuardianUiState(
    val loading: Boolean = true,
    val devices: List<DeviceOverview> = emptyList(),
    val selectedId: String = SupabaseConfig.DEFAULT_DEVICE,
    val latest: TelemetryRow? = null,
    val trend: List<TelemetryRow> = emptyList(),
    val alerts: List<FallEventRow> = emptyList(),
    val link: LinkState = LinkState.CONNECTING,
    val lastSync: Long = 0L,
    val query: String = "",
    val error: String? = null
) {
    val selected: DeviceOverview? get() = devices.firstOrNull { it.id == selectedId }
    val openAlerts: List<FallEventRow> get() = alerts.filter { !it.acknowledged }
    val visibleDevices: List<DeviceOverview>
        get() = if (query.isBlank()) devices else devices.filter {
            it.name.contains(query, true) ||
                it.id.contains(query, true) ||
                (it.room ?: "").contains(query, true)
        }
}

class GuardianViewModel : ViewModel() {

    private val _state = MutableStateFlow(GuardianUiState())
    val state: StateFlow<GuardianUiState> = _state.asStateFlow()

    private val refreshLock = Mutex()

    init {
        viewModelScope.launch { pollForever() }
        viewModelScope.launch { followRealtime() }
    }

    fun select(deviceId: String) {
        _state.value = _state.value.copy(selectedId = deviceId, trend = emptyList(), latest = null)
        viewModelScope.launch { refresh() }
    }

    fun search(text: String) {
        _state.value = _state.value.copy(query = text)
    }

    fun respond(event: FallEventRow, response: AlertResponse) {
        viewModelScope.launch {
            runCatching { GuardianRepository.respond(event.id, response) }
                .onSuccess { refresh() }
                .onFailure { e -> _state.value = _state.value.copy(error = e.message) }
        }
    }

    fun retry() {
        viewModelScope.launch { refresh() }
    }

    /**
     * Polling is the backbone: it works on any network, including the captive
     * hotel wifi that blocks websockets. Realtime only makes it feel instant.
     */
    private suspend fun pollForever() {
        while (true) {
            refresh()
            delay(2_500)
        }
    }

    private suspend fun followRealtime() {
        while (true) {
            runCatching {
                GuardianRepository.liveSignals().collect { signal ->
                    when (signal) {
                        is RealtimeSignal.Connected ->
                            _state.value = _state.value.copy(link = LinkState.LIVE)

                        is RealtimeSignal.Dropped ->
                            _state.value = _state.value.copy(link = LinkState.POLLING)

                        is RealtimeSignal.Row -> refresh()
                    }
                }
            }
            _state.value = _state.value.copy(link = LinkState.POLLING)
            delay(8_000)          // socket died, back off before trying again
        }
    }

    private suspend fun refresh() = refreshLock.withLock {
        val current = _state.value
        try {
            val devices = GuardianRepository.devices()
            val id = when {
                devices.any { it.id == current.selectedId } -> current.selectedId
                devices.isNotEmpty() -> devices.first().id
                else -> current.selectedId
            }
            val trend = if (devices.isEmpty()) emptyList() else GuardianRepository.trend(id)
            val alerts = GuardianRepository.alerts()

            _state.value = current.copy(
                loading = false,
                devices = devices,
                selectedId = id,
                latest = trend.lastOrNull(),
                trend = trend,
                alerts = alerts,
                lastSync = System.currentTimeMillis(),
                error = null
            )
        } catch (e: Exception) {
            _state.value = current.copy(
                loading = false,
                link = LinkState.POLLING,
                error = e.message ?: "Cannot reach Supabase"
            )
        }
    }
}
